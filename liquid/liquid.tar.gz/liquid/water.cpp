#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <cstring>
#include <stdarg.h>
#include <time.h>
#include <math.h>
#include <string>
#include "tga.h"
#include <xgl.h>
#include <SDL.h>
using ::std::string;

#define GRIDRES 100
#define SQRTOFTWOINV 1.0 / 1.414213562
#define FPS 50
#define DEFAULTAMP .05f

typedef float vec_t;
typedef vec_t vec3_t[3];

enum {
    LEFT = 0, 
    RIGHT,
};

int mx,my;
int mButton = -1;
int mOldY, mOldX;
int width, height;

vec3_t eye = {(float)GRIDRES/2.f, -(float)GRIDRES/2.2f , (float)GRIDRES * 1.41421f};
vec3_t rot = {45.0f, .0f, 0.0f};

int	texmode    = 1,
	envMap     = 1,
	rainy      = 0,
	go         = 1;
int	tStart,
	tCur,
	tFps;
int	tf      = 0,
	nf      = 0,
	showFps = FPS;
int	speed   = FPS;
float	raindrop= .001f * (float)GRIDRES;

int	size = GRIDRES;
float	hw   = DEFAULTAMP * (float)GRIDRES;
float	dt   = 1.f / (float) FPS;
float	tval = 1.0f/(float)GRIDRES;

float surf[GRIDRES][GRIDRES][3];
float norm[GRIDRES][GRIDRES][3];
float force[GRIDRES][GRIDRES];
float veloc[GRIDRES][GRIDRES];

float LightAmbient[] =	{ 1.0f, 1.0f, 1.0f, 1.0f };
float LightDiffuse[] =	{ 1.0f, .0f, 1.0f, 1.0f };
float LightPosition[]=	{ 0.0f, 0.0f, -20.0f, 1.0f };

void ResetSurface(void);
void DrawSurface(void);
void MakeNorm(void);
void Wave(void);

void sdlQuit(int rc) {
	SDL_Quit( );
	XGLShutdown();
	exit(rc);
}

void sdlResize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(55.0, (float)w/(float)h, 1.0, 1000.0);
	glMatrixMode(GL_MODELVIEW);
	width = w;
	height= h;
}

void sdlKeyboard(SDL_keysym* key) {
	bool do_env=false;
	switch (key->sym) {
		case SDLK_ESCAPE: exit(0);
		case SDLK_SPACE:
			ResetSurface();
			return;
		case SDLK_g:
			go = !go;
			return;
		case SDLK_t:
			texmode = !texmode;
			if (texmode) {
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_DEPTH_TEST);
				glEnable(GL_LIGHTING);
			}
			else {
				glDisable(GL_TEXTURE_2D);
				glDisable(GL_DEPTH_TEST);
				glDisable(GL_LIGHTING);
			}
			return;
		case SDLK_e:
			envMap = !envMap;
			if (envMap) do_env=true;
			else {
				glBindTexture(GL_TEXTURE_2D, 1);
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
				glDisable(GL_TEXTURE_GEN_S);
				glDisable(GL_TEXTURE_GEN_T);
			}
			break;
		case SDLK_r:
			rainy = !rainy;
			break;
		case SDLK_a:
			hw++;
			printf("wave %f\n", hw);
			return;
		case SDLK_w:
			hw--;
			printf("wave %f\n", hw);
			return;
		
		case SDLK_s:
			if (speed<1000) speed++;
			printf("speed: %d (fps)\n", speed);
			return;
		
		case SDLK_x:
			if (speed>1) speed--;
			printf("speed: %d (fps)\n", speed);
			return;

		case SDLK_KP1: loadTGA("textures/phong.tga", 1);
			if(envMap) do_env=true;
			break;

		case SDLK_KP2: loadTGA("textures/tunnel3.tga", 1);
			if(envMap) do_env=true;
			break;

		case SDLK_KP3: loadTGA("textures/proto_zzztblu2.tga", 1);
			if(envMap) do_env=true;
			break;
		case SDLK_KP4: loadTGA("textures/marble1.tga", 1);
			if(envMap) do_env=true;
			break;
		case SDLK_KP5: loadTGA("textures/layeredrock.tga", 1);
			if(envMap) do_env=true;
			break;
	}
	if (do_env) {
		glBindTexture(GL_TEXTURE_2D, 1);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}
}

void clamp(vec3_t v) {
	int i;
	for (i = 0; i < 3; i ++)
		if (v[i] > 360 || v[i] < -360)
			v[i] = 0;
}

void sdlMotion(SDL_MouseMotionEvent* e) {
	int m, n;
	int ihw;

	if (mButton == LEFT) {
		m = (int)((float)e->x/width  * size);
		n = (int)((float)e->y/height * size);
		ihw = - (int) ((float)hw * ((float)rand()/(float)RAND_MAX));

		surf[m][n][1]     = ihw;
		surf[m][n+1][1]   = ihw;
		surf[m+1][n][1]   = ihw;
		surf[m+1][n+1][1] = ihw;
	}
	else if (mButton == RIGHT) {
		eye[2] -= ((mOldY - e->y) * 180.0f) / 200.0f;
		clamp(rot);
	}
	mOldX = e->x;
	mOldY = e->y;
}

void sdlMouse(SDL_MouseButtonEvent* e) {
	int m, n, ihw;
	m = (int)((float)e->x/width * size);
	n = (int)((float)e->y/height * size);
	if (e->type == SDL_MOUSEBUTTONDOWN) {
		switch (e->button) {
			case SDL_BUTTON_LEFT: {
				mButton = LEFT;
				ihw = (int) ((float)hw * ((float)rand()/(float)RAND_MAX));
				surf[m][n][1] -= ihw;
				surf[m][n+1][1] -= ihw;
				surf[m+1][n][1] -= ihw;
				surf[m+1][n+1][1] -= ihw;
				break;
			}
			case SDL_BUTTON_RIGHT: mButton = RIGHT; break;
		}
	}
	else if (e->type == SDL_MOUSEBUTTONUP) mButton = -1;
	mOldX = e->x;
	mOldY = e->y;
}

void glprint(int x_in, int y_in, float size, char *s, ...) {
	unsigned char c;
	int i, l, x,y;
   
	float tx,ty, xsize, ysize, fxsize=.0625, fysize=.125;
   
	va_list	msg;
	char buffer[1024] = {'\0'};

	va_start(msg, s);
	vsprintf(buffer, s, msg);	
	va_end(msg);
   
	x = x_in;
	y = height - y_in;
	l = strlen(buffer);
	xsize = size * 0.5f;
	ysize = size;
	size *= 0.45f;
	glColor4d(1, 1, 1, 1);
   
	if (texmode==0) glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glBindTexture(GL_TEXTURE_2D, 2);
	if (envMap) {
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	}
	glPushAttrib(GL_POLYGON_MODE);
	glPolygonMode(GL_FRONT,GL_FILL);
	glPushMatrix();
	glPushAttrib(GL_VIEWPORT_BIT);
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1.0f, 1.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	for (i=0; i<l; i++) {
		c = buffer[i]-32;
		if (c) {
			tx = (c % 16) * fxsize + 0.01f;
			ty = (1 - fysize) - (int) (c * 0.0625f) * fysize - 0.01f;
			glBegin(GL_QUADS);
			glTexCoord2f(tx       , ty);         glVertex2f(x      , y);
			glTexCoord2f(tx+fxsize, ty);         glVertex2f(x+xsize, y);
			glTexCoord2f(tx+fxsize, ty+fysize);  glVertex2f(x+xsize, y+ysize);
			glTexCoord2f(tx       , ty+fysize);  glVertex2f(x      , y+ysize);
			glEnd();
		}
		x+=(int)size;
	}
	glPopMatrix();
	glPopAttrib();
	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
	if (envMap) {
		glBindTexture(GL_TEXTURE_2D, 2);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}
	glPopAttrib();
	if (texmode==0) glDisable(GL_TEXTURE_2D);
	sdlResize(width, height);
}

void sdlDisplay(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	DrawSurface();

	if (go) {
		if (tCur-tFps > (int)(CLOCKS_PER_SEC/speed)) {
			MakeNorm();
			Wave();
			tFps = tCur;
		}
	}

	glprint(5,25,18.f,"Liquid fx: Springs grid + Environment Mapping");
	glprint(5,50,18.f,"Julien Cayzac <jcayzac@brainlex.com>");
	string mode;
	if (texmode) mode += "Textured ";
	else mode += "Wireframe ";
	if (envMap) mode+= "- Environment map ";
	else mode += "- Normal map ";
	if (rainy) mode += "- Rain ";
	if (go==0) mode += "(PAUSED)";
	char *mode_c = (char*)(void*)mode.c_str();
	glprint(5,75,18.f,mode_c);
	glprint(5,115,36.f,"%i FPS", showFps);
	speed = (FPS*FPS) / showFps;
	glPopMatrix();
	glFlush();
	SDL_GL_SwapBuffers();

	tCur = clock();
	if (tCur-tf>=CLOCKS_PER_SEC) {
		showFps = nf;
		tf = tCur;
		nf = 0;
	}
	else nf++;
}

void copy(float vec0[3], float vec1[3]) {
	vec0[0] = vec1[0];
	vec0[1] = vec1[1];
	vec0[2] = vec1[2];
}

void sub(float vec0[3], float vec1[3], float vec2[3]) {
	vec0[0] = vec1[0] - vec2[0];
	vec0[1] = vec1[1] - vec2[1];
	vec0[2] = vec1[2] - vec2[2];
}

void add(float vec0[3], float vec1[3], float vec2[3]) {
	vec0[0] = vec1[0] + vec2[0];
	vec0[1] = vec1[1] + vec2[1];
	vec0[2] = vec1[2] + vec2[2];
}

void scalDiv(float vec[3], float c) {
	vec[0] /= c;
	vec[1] /= c;
	vec[2] /= c;
}

void cross(float vec0[3], float vec1[3], float vec2[3]) {
	vec0[0] = vec1[1] * vec2[2] - vec1[2] * vec2[1];
	vec0[1] = vec1[2] * vec2[0] - vec1[0] * vec2[2];
	vec0[2] = vec1[0] * vec2[1] - vec1[1] * vec2[0];
}

void normz(float vec[3]) {
	float c = sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
	scalDiv(vec, c); 
}

void set(float vec[3], float x, float y, float z) {
	vec[0] = x;
	vec[1] = y;
	vec[2] = z;
}

void ResetSurface(void) {
	int i,j;

	for(i=0; i<size; i++)
	for(j=0; j<size; j++) {
		surf[i][j][0] = (float)i;
		surf[i][j][1] = 0;
		surf[i][j][2] = (float)j;

		force[i][j] = 0;
		veloc[i][j] = 0;
	}
}

void DrawSurface(void) {
	int i, j;

	glTranslatef(-eye[0], -eye[1], -eye[2]);
	glRotatef(rot[0], 1.0f, 0.0f, 0.0f);
	glRotatef(rot[1], 0.0f, 1.0f, 0.0f);
	glRotatef(rot[2], 0.0f, 0.0f, 1.0f);

	if (texmode) {
		glColor3f(1, 1, 1);	
		glBindTexture(GL_TEXTURE_2D, 1);

		for(j=0; j<size-1; j++) {
			int next = j+1;
			glBegin(GL_TRIANGLE_STRIP);
			for(i=0; i<size; i++) {
				glTexCoord2f((float)i*tval, (float)j*tval);
				glNormal3f((float)norm[i][j][0],	(float)norm[i][j][1],	(float)norm[i][j][2]);
				glVertex3f((float)surf[i][j][0],	(float)surf[i][j][1],	(float)surf[i][j][2]);

				glTexCoord2f((float)i*tval, (float)next*tval);
				glNormal3f((float)norm[i][next][0],	(float)norm[i][next][1],	(float)norm[i][next][2]);
				glVertex3f((float)surf[i][next][0],	(float)surf[i][next][1],	(float)surf[i][next][2]);
			}
			glEnd();
		}
	}
	else {
		glColor3f(1, 1, 1);
		for(i=0; i<size-1; i++)
		for(j=0; j<size-1; j++) {
			glBegin(GL_LINE_STRIP);	
			glVertex3f((float)surf[i][j][0],		(float)surf[i][j][1],		(float)surf[i][j][2]);
			glVertex3f((float)surf[i+1][j][0],		(float)surf[i+1][j][1],		(float)surf[i+1][j][2]);
			glVertex3f((float)surf[i+1][j+1][0],	(float)surf[i+1][j+1][1],	(float)surf[i+1][j+1][2]);
			glVertex3f((float)surf[i][j+1][0],		(float)surf[i][j+1][1],		(float)surf[i][j+1][2]);
			glVertex3f((float)surf[i][j][0],		(float)surf[i][j][1],		(float)surf[i][j][2]);
			glEnd();
		}

		glColor3f(0, 1, 0);
		for(i=0; i<size; i++)
		for(j=0; j<size; j++) {
			glBegin(GL_LINES);
			glVertex3f((float)surf[i][j][0], (float)surf[i][j][1], (float)surf[i][j][2]);
			glVertex3f((float)surf[i][j][0]+norm[i][j][0], (float)surf[i][j][1]+norm[i][j][1], (float)surf[i][j][2]+norm[i][j][2]);
			glEnd();
		}
	}
}

void MakeNorm(void) {
	int i, j;
	float a[3],b[3],c[3];

	for(i=0; i<size; i++)
	for(j=0; j<size; j++) {
		if (i!=size-1 && j!=size-1) {
			sub(a, surf[i][j+1], surf[i][j]);
			sub(b, surf[i+1][j], surf[i][j]);
		}
		else {
			sub(a, surf[i][j-1], surf[i][j]);
			sub(b, surf[i-1][j], surf[i][j]);
		}
		
		cross(c, a, b);
		normz(c);

		if (i==0 && j==size-1) {
			sub(a, surf[i][j-1], surf[i][j]);
			sub(b, surf[i+1][j], surf[i][j]);

			cross(c, a, b);
			normz(c);

			c[0]=-c[0]; c[1]=-c[1]; c[2]=-c[2];
		}
		
		if (i==size-1 && j==0) {
			sub(a, surf[i-1][j], surf[i][j]);
			sub(b, surf[i][j+1], surf[i][j]);

			cross(c, a, b);
			normz(c);
		}		
		
		copy(norm[i][j], c);
   }
}

void Wave(void) {
	int i,j;
	float d;
	float m=0;

	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
		force[i][j] = 0;

	for(i=1; i<size-1; i++)
	for(j=1; j<size-1; j++) {
		d=surf[i][j][1]-surf[i][j-1][1];
		force[i][j] -= d;
		force[i][j-1] += d;
		m += d;

		d=surf[i-1][j][1]-surf[i-1][j][1];
		force[i][j] -= d;
		force[i-1][j] += d;
		m += d;

		d=surf[i][j][1]-surf[i][j+1][1];
		force[i][j] -= d;
		force[i][j+1] += d;
		m += d;

		d=surf[i][j][1]-surf[i+1][j][1];
		force[i][j] -= d;
		force[i+1][j] += d;
		m += d;

		d=(surf[i][j][1]-surf[i+1][j+1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j+1] += d;
		m += d;

		d=(surf[i][j][1]-surf[i-1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i-1][j-1] += d;
		m += d;

		d=(surf[i][j][1]-surf[i+1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j-1] += d;
		m += d;

		d=(surf[i][j][1]-surf[i+1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j-1] += d;
		m += d;
	}

	if (rainy)
		surf[rand()%size][rand()%size][1] = raindrop;
	for(i=0; i<size; i++)
	for(j=0; j<size; j++) {
		veloc[i][j] += force[i][j] * dt;
		surf[i][j][1] += veloc[i][j];
		
		if (surf[i][j][1]>0) surf[i][j][1] -= surf[i][j][1]/size;
		else surf[i][j][1] -= surf[i][j][1]/size;
	}
}

int main(int argc, char *argv[]) {
	const SDL_VideoInfo* info = NULL;
	int bpp = 0;
	int flags = 0;
	cerr << "Init GL... ";
	XGLcaps caps;
	if (!XGLInitialize("/usr/lib/libGL.so", "/usr/X11R6/lib/libGLU.so")) {
		cerr << "FAILED: " << XGLErrorString << endl;
		sdlQuit(1);
	}
	cerr << "OK" << endl << "Init Video... ";
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		sdlQuit(1);
	info = SDL_GetVideoInfo();
	if(!info)
		sdlQuit(1);
	cerr << "OK" << endl << "Set GL Attributes... ";
	width = 800;
	height = 600;
	bpp = info->vfmt->BitsPerPixel;
	SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
	flags = SDL_OPENGL;
	cerr << "OK" << endl << "Set Video Mode... ";
	if( SDL_SetVideoMode( width, height, bpp, flags ) == 0 )
		sdlQuit(1);
	cerr << "OK" << endl << "Set GL... ";
	glShadeModel( GL_SMOOTH );
	glCullFace( GL_BACK );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glClearColor( 0, 0, 0, 0 );
	sdlResize(width, height);

	cerr << "OK" << endl << "Getting caps... ";
	XGLCheckCapabilities(&caps);
	cerr << "OK" << endl;
	
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);
	glEnable(GL_LIGHT1);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	int res;
	res = loadTGA("textures/tunnel3.tga", 1);
	res = loadTGA("textures/font.tga", 2);
	
	glBindTexture(GL_TEXTURE_2D, 1);
	if (envMap==1) {
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}
	else {
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
	}

	ResetSurface();
	
	tStart = clock();

	if (texmode==0) {
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_LIGHTING);
	}

	while (1) {
		SDL_Event event;
		while( SDL_PollEvent( &event ) ) {
			switch( event.type ) {
				case SDL_KEYDOWN:
					sdlKeyboard(&event.key.keysym);
					break;
				case SDL_MOUSEMOTION:
					sdlMotion(&event.motion);
					break;
				case SDL_MOUSEBUTTONUP:
				case SDL_MOUSEBUTTONDOWN:
					sdlMouse(&event.button);
					break;
				case SDL_QUIT:
					sdlQuit(0);
					break;
			}
		}
		sdlDisplay();
	}
	return 0;
}
