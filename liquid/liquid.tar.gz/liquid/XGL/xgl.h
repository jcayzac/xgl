/*
XGL v0.4

Copyright (c) 2002, Julien Cayzac <jcayzac@brainlex.com>
All rights reserved.

Redistribution  and  use   in  source  and  binary  forms,  with   or   without
modification,  are   permitted   provided   that   the   following   conditions
are met:

* Redistributions of  source code must retain the above  copyright notice, this
list of conditions and the following disclaimer.

* Redistributions  in binary form  must reproduce  the above  copyright notice,
this list  of conditions  and the  following  disclaimer  in the  documentation
and/or other materials provided with the distribution.

* Neither  the  name  of  BrainLeX  nor  the  names  of  its  contributors  may
be  used to  endorse or promote  products  derived from  this software  without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED  WARRANTIES, INCLUDING, BUT NOT  LIMITED TO, THE IMPLIED
WARRANTIES  OF  MERCHANTABILITY  AND  FITNESS  FOR  A  PARTICULAR  PURPOSE  ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT  LIMITED TO, PROCUREMENT  OF SUBSTITUTE  GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY  OF  LIABILITY,  WHETHER  IN  CONTRACT,  STRICT  LIABILITY, OR  TORT
(INCLUDING NEGLIGENCE  OR  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 Supported core versions: 1.1, 1.2, 1.2.1, 1.3
 Supported extensions:
 ARB_multitexture ARB_multisample ARB_texture_compression ARB_texture_cube_map
 ARB_texture_env_add ARB_texture_env_combine ARB_texture_env_dot3 ARB_texture_border_clamp
 ARB_transpose_matrix ARB_point_parameters ARB_vertex_blend ARB_matrix_palette
 ARB_texture_env_crossbar ARB_texture_mirrored_repeat ARB_depth_texture ARB_shadow
 ARB_shadow_ambient ARB_imaging
 EXT_color_table EXT_color_subtable EXT_convolution EXT_histogram EXT_blend_color
 EXT_blend_minmax EXT_blend_subtract EXT_texture3D EXT_bgra EXT_packed_pixels
 EXT_rescale_normal EXT_separate_specular_color EXT_texture_edge_clamp EXT_texture_lod
 EXT_draw_range_elements EXT_point_parameters EXT_abgr EXT_clip_volume_hint
 EXT_compiled_vertex_array EXT_fog_coord EXT_multi_draw_arrays EXT_secondary_color
 EXT_stencil_wrap EXT_texture_compression_s3tc EXT_texture_filter_anisotropic
 EXT_texture_lod_bias EXT_vertex_weighting EXT_vertex_shader
 NV_blend_square NV_copy_depth_to_color NV_depth_clamp NV_evaluators NV_fence
 NV_fog_distance NV_light_max_exponent NV_multisample_filter_hint NV_point_sprite
 NV_occlusion_query NV_packed_depth_stencil NV_register_combiners NV_register_combiners2
 NV_secondary_color_alpha NV_texgen_emboss NV_texgen_reflection NV_texture_compression_vtc
 NV_texture_env_combine4 NV_texture_rectangle NV_texture_shader NV_texture_shader2
 NV_texture_shader3 NV_vertex_array_range NV_vertex_array_range2 NV_vertex_program
 NV_vertex_program1_1
 ATI_envmap_bumpmap ATI_fragment_shader ATI_pn_triangles ATI_vertex_array_object
 ATI_vertex_streams
 SGI_color_matrix SGIS_texture_lod SGIS_generate_mipmap SGIS_fog_function SGI_vertex_preclip
 HP_convolution_border_modes HP_occlusion_test
 IBM_texture_mirrored_repeat
 WIN_specular_fog
 Supported GLU versions: 1.1, 1.2, 1.3
 Supported GLU extensions:
 EXT_nurbs_tesselator, EXT_object_space_tess
*/

#if !defined(__XGL)
#define __XGL

#if (defined(__gl_h_) || defined(__GL_H__) || defined(__gl_h__))
#error "Do not manually include GL/gl.h! Use xgl.h instead."
#endif
#if (defined(__glu_h_) || defined(__GLU_H__) || defined(__glu_h__))
#error "Do not manually include GL/glu.h! Use xgl.h instead."
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32) && !defined(APIENTRY) && !defined(__CYGWIN__)
#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#endif

#ifdef _WIN32
#define __xglapi __stdcall
#undef wglChoosePixelFormat
#undef ChoosePixelFormat
#else
#define __xglapi
#endif

/* GL types */
typedef unsigned int GLenum;
typedef unsigned char GLboolean;
typedef unsigned int GLbitfield;
typedef signed char GLbyte;
typedef short GLshort;
typedef int GLint;
typedef int GLsizei;
typedef unsigned char GLubyte;
typedef unsigned short GLushort;
typedef unsigned int GLuint;
typedef float GLfloat;
typedef float GLclampf;
typedef double GLdouble;
typedef double GLclampd;
typedef void GLvoid;

/* GLU types */
#ifdef __cplusplus
class GLUnurbs;
class GLUquadric;
class GLUtesselator;
#else
typedef struct GLUnurbs GLUnurbs;
typedef struct GLUquadric GLUquadric;
typedef struct GLUtesselator GLUtesselator;
#endif
typedef struct GLUnurbs GLUnurbsObj;
typedef struct GLUquadric GLUquadricObj;
typedef struct GLUtesselator GLUtesselatorObj;
typedef struct GLUtesselator GLUtriangulatorObj;
typedef void (*_GLUfuncptr)();

/* GL enumerants */
#include "enum.xgl"
/* GLU enumerants */
#include "uenum.xgl"

#define XGLFunc(_name_, _ret_, _args_) \
typedef _ret_ (__xglapi* _name_##_fptr) _args_; \
extern _name_##_fptr _name_;
/* GL function pointers */
#include "func.xgl"
/* GLU function pointers */
#include "ufunc.xgl"
#undef XGLFunc

/**************************** PUBLIC API STARTS HERE ************************/

/* GL functionalities information */
typedef struct {
	GLboolean	/* supported core versions */
			gl_11,				/* 1.1 */
			gl_12,				/* 1.2 */
			gl_121,				/* 1.2.1 */
			gl_13,				/* 1.3 */
			gl_20,				/* 2.0 */
			imaging,			/* optional imaging functions (ARB_imaging) for GL 1.2+ */
			/* Imaging caps: */
			color_table,			/* fallback: EXT_color_table+EXT_color_subtable */
			convolution,			/* fallback: EXT_convolution+HP_convolution_border_modes */
			color_matrix,			/* fallback: SGI_color_matrix */
			histogram,			/* fallback: EXT_histogram */
			blend_color,			/* fallback: EXT_blend_color */
			blend_minmax,			/* fallback: EXT_blend_minmax */
			blend_substract,		/* fallback: EXT_blend_subtract */
			/* GL 2.0 caps: */
							/* none yet. */
			/* GL 1.3 caps: */
			multitexture,			/* fallback: ARB_multitexture */
			multisample,			/* fallback: ARB_multisample */
			texture_compression,		/* fallback: ARB_texture_compression */
			texture_cube_map,		/* fallback: ARB_texture_cube_map */
			texture_env_add,		/* fallback: ARB_texture_env_add */
			texture_env_combine,		/* fallback: ARB_texture_env_combine */
			texture_env_dot3,		/* fallback: ARB_texture_env_dot3 */
			texture_border_clamp,		/* fallback: ARB_texture_border_clamp */
			transpose_matrix,		/* fallback: ARB_transpose_matrix */

			/* GL 1.2 caps: */
			texture3D,			/* fallback: EXT_texture3D */
			bgra,				/* fallback: EXT_bgra */
			packed_pixels,			/* fallback: EXT_packed_pixels */
			rescale_normal,			/* fallback: EXT_rescale_normal */
			separate_specular_color,	/* fallback: EXT_separate_specular_color */
			texture_edge_clamp,		/* fallback: EXT_texture_edge_clamp or SGIS_texture_edge_clamp */
			texture_lod,			/* fallback: EXT_texture_lod or SGIS_texture_lod */
			draw_range_elements,		/* fallback: EXT_draw_range_elements */
			
			/* current (ARB) caps: */
			point_parameters,		/* fallback: EXT_point_parameters */
			vertex_blend,			/*  */
			matrix_palette,			/*  */
			texture_env_crossbar,		/*  */
			texture_mirrored_repeat,	/* fallback: IBM_texture_mirrored_repeat */
			depth_texture,			/* fallback: SGIX_depth_texture (unsupported) */
			shadow,				/* fallback: SGIX_shadow  (unsupported) */
			shadow_ambient,			/* fallback: SGIX_ambient (unsupported) */

			/* common (EXT) caps: */
			abgr,				/*  */
			clip_volume_hint,		/*  */
			compiled_vertex_array,		/*  */
			fog_coord,			/*  */
			multi_draw_arrays,		/*  */
			secondary_color,		/*  */
			stencil_wrap,			/*  */
			texture_compression_s3tc,	/* fallback: S3_s3tc (unsupported) */
			texture_filter_anisotropic,	/*  */
			texture_lod_bias,		/*  */
			vertex_weighting,		/*  */
			vertex_shader,			/*  */
		
			/* Vendor specific caps: */
			/* -NVidia- */
			nv_blend_square,		/*  */
			nv_copy_depth_to_color,		/*  */
			nv_depth_clamp,			/*  */
			nv_evaluators,			/*  */
			nv_fence,			/*  */
			nv_fog_distance,		/*  */
			nv_light_max_exponent,		/*  */
			nv_multisample_filter_hint,	/* -Quincunx filtering- */
			nv_occlusion_query,		/*  */
			nv_packed_depth_stencil,	/*  */
			nv_point_sprite,		/*  */
			nv_register_combiners,		/*  */
			nv_register_combiners2,		/*  */
			nv_secondary_color_alpha,	/*  */
			nv_texgen_emboss,		/*  */
			nv_texgen_reflection,		/*  */
			nv_texture_compression_vtc,	/*  */
			nv_texture_env_combine4,	/*  */
			nv_texture_rectangle,		/*  */
			nv_texture_shader,		/*  */
			nv_texture_shader2,		/*  */
			nv_texture_shader3,		/*  */
			nv_vertex_array_range,		/*  */
			nv_vertex_array_range2,		/*  */
			nv_vertex_program,		/*  */
			nv_vertex_program1_1,		/*  */
			/* -ATI- */
			ati_envmap_bumpmap,		/*  */
			ati_fragment_shader,		/*  */
			ati_pn_triangles,		/* -ATI TrueForm- */
			ati_vertex_array_object,	/*  */
			ati_vertex_streams,		/*  */
			/* -HP- */
			hp_occlusion_test,		/* -prefer nv_occlusion_query for parallelism- */
			/* -SGI- */
			sgis_generate_mipmap,		/*  */
			sgis_fog_function,		/*  */
			sgi_vertex_preclip,		/* same as sgix_vertex_preclip -HINT for fast clipping- */
			/* -WIN- */
			win_specular_fog;		/* */
	/* GLU capabilities */
	struct {
	GLboolean	glu_11,				/* version info */
			glu_12,
			glu_13,
			nurbs_callback,			/* in 1.2 */
			check_extensions,		/* in 1.3 (gluCheckExtension()) */
			mipmap3D,			/* in 1.3 (glu3DMipmaps()) */
			mipmap_levels,			/* in 1.3 (gluBuild{123}DMipmapLevels()) */
			unproject4,			/* in 1.3 (gluUnproject4()) */
			/* extensions */
			nurbs_tessellator,		/* GLU_EXT_nurbs_tessellator */
			object_space_tess;		/* GLU_EXT_object_space_tess */
	} glu;
} XGLcaps;

/* Last error: */
extern const GLubyte* XGLErrorString;
/* OpenGL info */
extern const GLubyte* XGLVersionString;
extern const GLubyte* XGLExtensionsString;
/* GLU info */
extern const GLubyte* XGLUVersionString;
extern const GLubyte* XGLUExtensionsString;

/* Initializer. gluDllPath is optional and can be NULL */
extern GLboolean XGLInitialize(const char* glDllPath, const char* gluDllPath);
/* Fill in the XGLcaps structure. */
extern void XGLCheckCapabilities(XGLcaps* caps);
/* Find an extension by name (usefull for finding unsupported extensions) */
extern GLboolean XGLFindCapByName(const char*);
/* Close the opened DLLs. */
extern void XGLShutdown(void);

/**************************** PUBLIC API ENDS HERE ***************************/

/* Common WGL/GLX extensions */
#define XGLFunc(_name_, _ret_, _args_) \
typedef _ret_ (__xglapi* XGL##_name_##_fptr) _args_; \
extern XGL##_name_##_fptr GL##_name_;
XGLFunc(GetProcAddress, void*, (const GLubyte*))
#include "xfunc.xgl"
#undef XGLFunc


#ifdef __cplusplus
}
#endif

#endif

