//#include <GL/gl.h>
#include "GL.h"
#include <SDL/SDL.h>
//#include <GL/glu.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <iostream>
using std::cerr;
using std::endl;

static GLboolean should_rotate = GL_TRUE;

static void quit_tutorial( int code ) {
	SDL_Quit( );
	GLShutdown();
	exit(code);
}

static void handle_key_down( SDL_keysym* keysym ) {
	switch( keysym->sym ) {
		case SDLK_ESCAPE:
			quit_tutorial( 0 );
			break;
		case SDLK_SPACE:
			should_rotate = !should_rotate;
			break;
	}
}

static void process_events( void ) {
	SDL_Event event;
	while( SDL_PollEvent( &event ) ) {
		switch( event.type ) {
			case SDL_KEYDOWN:
				handle_key_down( &event.key.keysym );
				break;
			case SDL_QUIT:
				quit_tutorial( 0 );
				break;
		}
	}
}
static void draw_screen( void ){
	static float angle = 0.0f;

	static GLfloat v0[] = { -1.0f, -1.0f,  1.0f };
	static GLfloat v1[] = {  1.0f, -1.0f,  1.0f };
	static GLfloat v2[] = {  1.0f,  1.0f,  1.0f };
	static GLfloat v3[] = { -1.0f,  1.0f,  1.0f };
	static GLfloat v4[] = { -1.0f, -1.0f, -1.0f };
	static GLfloat v5[] = {  1.0f, -1.0f, -1.0f };
	static GLfloat v6[] = {  1.0f,  1.0f, -1.0f };
	static GLfloat v7[] = { -1.0f,  1.0f, -1.0f };
	static GLubyte red[]    = { 255,   0,   0, 255 };
	static GLubyte green[]  = {   0, 255,   0, 255 };
	static GLubyte blue[]   = {   0,   0, 255, 255 };
	static GLubyte white[]  = { 255, 255, 255, 255 };
	static GLubyte yellow[] = {   0, 255, 255, 255 };
	static GLubyte black[]  = {   0,   0,   0, 255 };
	static GLubyte orange[] = { 255, 255,   0, 255 };
	static GLubyte purple[] = { 255,   0, 255,   0 };

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity( );
	glTranslatef( 0.0, 0.0, -5.0 );
	glRotatef( angle, 0.0, 1.0, 0.0 );
	if( should_rotate ) {
		if( ++angle > 360.0f )
			angle = 0.0f;
	}
	glBegin( GL_TRIANGLES );
	glColor4ubv( red );
	glVertex3fv( v0 );
	glColor4ubv( green );
	glVertex3fv( v1 );
	glColor4ubv( blue );
	glVertex3fv( v2 );
	glColor4ubv( red );
	glVertex3fv( v0 );
	glColor4ubv( blue );
	glVertex3fv( v2 );
	glColor4ubv( white );
	glVertex3fv( v3 );
	glColor4ubv( green );
	glVertex3fv( v1 );
	glColor4ubv( black );
	glVertex3fv( v5 );
	glColor4ubv( orange );
	glVertex3fv( v6 );
	glColor4ubv( green );
	glVertex3fv( v1 );
	glColor4ubv( orange );
	glVertex3fv( v6 );
	glColor4ubv( blue );
	glVertex3fv( v2 );
	glColor4ubv( black );
	glVertex3fv( v5 );
	glColor4ubv( yellow );
	glVertex3fv( v4 );
	glColor4ubv( purple );
	glVertex3fv( v7 );
	glColor4ubv( black );
	glVertex3fv( v5 );
	glColor4ubv( purple );
	glVertex3fv( v7 );
	glColor4ubv( orange );
	glVertex3fv( v6 );
	glColor4ubv( yellow );
	glVertex3fv( v4 );
	glColor4ubv( red );
	glVertex3fv( v0 );
	glColor4ubv( white );
	glVertex3fv( v3 );
        glColor4ubv( yellow );
	glVertex3fv( v4 );
	glColor4ubv( white );
	glVertex3fv( v3 );
	glColor4ubv( purple );
	glVertex3fv( v7 );
	glColor4ubv( white );
	glVertex3fv( v3 );
	glColor4ubv( blue );
	glVertex3fv( v2 );
	glColor4ubv( orange );
	glVertex3fv( v6 );
	glColor4ubv( white );
	glVertex3fv( v3 );
	glColor4ubv( orange );
	glVertex3fv( v6 );
	glColor4ubv( purple );
	glVertex3fv( v7 );
	glColor4ubv( green );
	glVertex3fv( v1 );
	glColor4ubv( red );
	glVertex3fv( v0 );
	glColor4ubv( yellow );
	glVertex3fv( v4 );
	glColor4ubv( green );
	glVertex3fv( v1 );
	glColor4ubv( yellow );
	glVertex3fv( v4 );
	glColor4ubv( black );
	glVertex3fv( v5 );
	glEnd( );
	SDL_GL_SwapBuffers( );
}

static void setup_opengl( int width, int height ) {
	float ratio = (float) width / (float) height;
	glShadeModel( GL_SMOOTH );
	glCullFace( GL_BACK );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glClearColor( 0, 0, 0, 0 );
	glViewport( 0, 0, width, height );
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );
//	gluPerspective( 60.0, ratio, 1.0, 1024.0 );
	GLdouble xmin, xmax, ymin, ymax;
	ymax = tan( 60 * 3.1415927 / 360.0 );
	ymin = -ymax;
	xmin = ymin * ratio;
	xmax = ymax * ratio;
	glFrustum( xmin, xmax, ymin, ymax, 1.0, 1024.0 );
}
	
int main(void) {
	const SDL_VideoInfo* info = NULL;
	int width = 0;
	int height = 0;
	int bpp = 0;
	int flags = 0;
	cerr << "Init GL... ";
	GLcaps caps;
	if (!GLInitialize("/usr/lib/libGL.so")) {
		cerr << "FAILED: " << GLErrorString << endl;
		quit_tutorial( 1 );
	}
	cerr << "OK" << endl << "Init Video... ";
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		quit_tutorial( 1 );
	cerr << "OK" << endl << "Get Video Info... ";
	info = SDL_GetVideoInfo();
	if(!info)
		quit_tutorial( 1 );
	cerr << "OK" << endl << "Set GL Attributes... ";
	width = 640;
	height = 480;
	bpp = info->vfmt->BitsPerPixel;
	SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
	flags = SDL_OPENGL/* | SDL_FULLSCREEN*/;
	cerr << "OK" << endl << "Set Video Mode... ";
	if( SDL_SetVideoMode( width, height, bpp, flags ) == 0 )
		quit_tutorial( 1 );
	cerr << "OK" << endl << "Set GL... ";
	setup_opengl( width, height );
	cerr << "OK" << endl;

	GLCheckCapabilities(&caps);

	cerr << "Supported GL core versions: ";
	if (caps.gl_20==GL_TRUE) cerr << "2.0 and older" << endl;
	else if (caps.gl_13==GL_TRUE) cerr << "1.3 and older" << endl;
	else if (caps.gl_121==GL_TRUE) cerr << "1.2.1 and older" << endl;
	else if (caps.gl_12==GL_TRUE) cerr << "1.2 and older" << endl;
	else if (caps.gl_11==GL_TRUE) cerr << "1.1 and older" << endl;

	cerr << "Optional Imaging Subset:" << endl;
	cerr << " Color Table:            " << (const char*) ((caps.color_table==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Convolution:            " << (const char*) ((caps.convolution==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Color Matrix:           " << (const char*) ((caps.color_matrix==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Histogram:              " << (const char*) ((caps.histogram==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Blend Color:            " << (const char*) ((caps.blend_color==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Blend Min/Max:          " << (const char*) ((caps.blend_minmax==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Blend Substract:        " << (const char*) ((caps.blend_substract==GL_TRUE)?"Yes":"No") << endl;
	cerr << "GL 1.3 caps:" << endl;
	cerr << " Multitexture:           " << (const char*) ((caps.multitexture==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Multisample:            " << (const char*) ((caps.multisample==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Compression:    " << (const char*) ((caps.texture_compression==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Cube Map:       " << (const char*) ((caps.texture_cube_map==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Env Add:        " << (const char*) ((caps.texture_env_add==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Env Combine:    " << (const char*) ((caps.texture_env_combine==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Env Dot3:       " << (const char*) ((caps.texture_env_dot3==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Border Clamp:   " << (const char*) ((caps.texture_border_clamp==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Transpose Matrix:       " << (const char*) ((caps.transpose_matrix==GL_TRUE)?"Yes":"No") << endl;
	cerr << "GL 1.2 caps:" << endl;
	cerr << " Texture 3D:             " << (const char*) ((caps.texture3D==GL_TRUE)?"Yes":"No") << endl;
	cerr << " BGRA Color Format:      " << (const char*) ((caps.bgra==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Packed Pixels:          " << (const char*) ((caps.packed_pixels==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Rescale Normal:         " << (const char*) ((caps.rescale_normal==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Separate Spec Color:    " << (const char*) ((caps.separate_specular_color==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Edge Clamp:     " << (const char*) ((caps.texture_edge_clamp==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture LOD:            " << (const char*) ((caps.texture_lod==GL_TRUE)?"Yes":"No") << endl;
	cerr << " DrawRangeElements():    " << (const char*) ((caps.draw_range_elements==GL_TRUE)?"Yes":"No") << endl;
	cerr << "Current caps:" << endl;
	cerr << " Point Parameters:       " << (const char*) ((caps.point_parameters==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Vertex Blend:           " << (const char*) ((caps.vertex_blend==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Matrix Palette:         " << (const char*) ((caps.matrix_palette==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Env Crossbar:   " << (const char*) ((caps.texture_env_crossbar==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Mirror Repeat:  " << (const char*) ((caps.texture_mirrored_repeat==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Depth Texture:          " << (const char*) ((caps.depth_texture==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Shadow:                 " << (const char*) ((caps.shadow==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Shadow Ambient:         " << (const char*) ((caps.shadow_ambient==GL_TRUE)?"Yes":"No") << endl;
	cerr << "Common caps:" << endl;
	cerr << " ABGR Color Format:      " << (const char*) ((caps.abgr==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Clip Volume Hint:       " << (const char*) ((caps.clip_volume_hint==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Compiled Vertex Array:  " << (const char*) ((caps.compiled_vertex_array==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Fog Coordinates:        " << (const char*) ((caps.fog_coord==GL_TRUE)?"Yes":"No") << endl;
	cerr << " MultiDrawArrays():      " << (const char*) ((caps.multi_draw_arrays==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Secondary Color:        " << (const char*) ((caps.secondary_color==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Stencil Wrap:           " << (const char*) ((caps.stencil_wrap==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Comp. S3TC:     " << (const char*) ((caps.texture_compression_s3tc==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture Filter Aniso.:  " << (const char*) ((caps.texture_filter_anisotropic==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Texture LOD Bias:       " << (const char*) ((caps.texture_lod_bias==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Vertex Weighting:       " << (const char*) ((caps.vertex_weighting==GL_TRUE)?"Yes":"No") << endl;
	cerr << " Vertex Shader:          " << (const char*) ((caps.vertex_shader==GL_TRUE)?"Yes":"No") << endl;
	cerr << "Proprietary caps:" << endl;
	cerr << " (NV) Blend Square:      " << (const char*) ((caps.nv_blend_square==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Copy Depth->Color: " << (const char*) ((caps.nv_copy_depth_to_color==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Depth Clamp:       " << (const char*) ((caps.nv_depth_clamp==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Evaluators:        " << (const char*) ((caps.nv_evaluators==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Fog Distance:      " << (const char*) ((caps.nv_fog_distance==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Light Max Expnt:   " << (const char*) ((caps.nv_light_max_exponent==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Q. Filtering:      " << (const char*) ((caps.nv_multisample_filter_hint==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Occlusion Query:   " << (const char*) ((caps.nv_occlusion_query==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Packed Dpth/Stncl: " << (const char*) ((caps.nv_packed_depth_stencil==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Point Sprite:      " << (const char*) ((caps.nv_point_sprite==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Reg. Combiners:    " << (const char*) ((caps.nv_register_combiners==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Reg. Combiners 2:  " << (const char*) ((caps.nv_register_combiners2==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Sec. Color Alpha:  " << (const char*) ((caps.nv_secondary_color_alpha==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) TexGen Emboss:     " << (const char*) ((caps.nv_texgen_emboss==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) TexGen Reflection: " << (const char*) ((caps.nv_texgen_reflection==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Comp. VTC: " << (const char*) ((caps.nv_texture_compression_vtc==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Env Comb4: " << (const char*) ((caps.nv_texture_env_combine4==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Rectangle: " << (const char*) ((caps.nv_texture_rectangle==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Shader:    " << (const char*) ((caps.nv_texture_shader==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Shader 2:  " << (const char*) ((caps.nv_texture_shader2==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Texture Shader 3:  " << (const char*) ((caps.nv_texture_shader3==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) VAR:               " << (const char*) ((caps.nv_vertex_array_range==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) VAR 2:             " << (const char*) ((caps.nv_vertex_array_range2==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Vertex Program:    " << (const char*) ((caps.nv_vertex_program==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (NV) Vertex Program 1.1:" << (const char*) ((caps.nv_vertex_program1_1==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (ATI) EMBM:             " << (const char*) ((caps.ati_envmap_bumpmap==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (ATI) Fragment Shader:  " << (const char*) ((caps.ati_fragment_shader==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (ATI) TruForm:          " << (const char*) ((caps.ati_pn_triangles==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (ATI) VAO:              " << (const char*) ((caps.ati_vertex_array_object==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (ATI) Vertex Streams:   " << (const char*) ((caps.ati_vertex_streams==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (HP) Occlusion Test:    " << (const char*) ((caps.hp_occlusion_test==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (SGI) Generate MipMap:  " << (const char*) ((caps.sgis_generate_mipmap==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (SGI) Fog Function:     " << (const char*) ((caps.sgis_fog_function==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (SGI) Vertex Preclip:   " << (const char*) ((caps.sgi_vertex_preclip==GL_TRUE)?"Yes":"No") << endl;
	cerr << " (WIN) Specular Fog:     " << (const char*) ((caps.win_specular_fog==GL_TRUE)?"Yes":"No") << endl;
	
	while( 1 ) {
		process_events( );
		draw_screen( );
	}
	return 0;
}

