/*
 * Dynamic OpenGL wrapper
 * v1.0
 *
 * TODO: 
 * 1/ Charger les fonctions core dans le driver
 * 2/ Charger les extensions avec le {wgl|glX}GetProcAddress() juste p�cho
 *
 */

#if !defined(__REF_GL)
#define __REF_GL

#if (defined(__gl_h_) || defined(__GL_H__) || defined(__gl_h__))
#error "Do not manually include GL/gl.h! Use GL.h instead."
#endif
#if (defined(__glu_h_) || defined(__GLU_H__) || defined(__glu_h__))
#error "Do not manually include GL/glu.h! Use GL.h instead."
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32) && !defined(APIENTRY) && !defined(__CYGWIN__)
#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#endif

#ifdef _WIN32
#define __glapi __stdcall
#undef wglChoosePixelFormat
#undef ChoosePixelFormat
#else
#define __glapi
#endif

// GL types
typedef unsigned int GLenum;
typedef unsigned char GLboolean;
typedef unsigned int GLbitfield;
typedef signed char GLbyte;
typedef short GLshort;
typedef int GLint;
typedef int GLsizei;
typedef unsigned char GLubyte;
typedef unsigned short GLushort;
typedef unsigned int GLuint;
typedef float GLfloat;
typedef float GLclampf;
typedef double GLdouble;
typedef double GLclampd;
typedef void GLvoid;

// GL Enumerants
#include "GL.tokens"

// GL Function pointers
#define GLFunc(_name_, _ret_, _args_) \
typedef _ret_ (__glapi* _name_##_fptr) _args_; \
extern _name_##_fptr _name_;
#include "GL.func"
#undef GLFunc

// GL functionalities information
typedef struct {
	GLboolean	// supported core versions
			gl_11,				// 1.1
			gl_12,				// 1.2
			gl_121,				// 1.2.1
			gl_13,				// 1.3
			gl_20,				// 2.0
			imaging,			// optional imaging functions (ARB_imaging) for GL 1.2+
			// Imaging caps:
			color_table,			// fallback: EXT_color_table+EXT_color_subtable
			convolution,			// fallback: EXT_convolution+HP_convolution_border_modes
			color_matrix,			// fallback: SGI_color_matrix
			histogram,			// fallback: EXT_histogram
			blend_color,			// fallback: EXT_blend_color
			blend_minmax,			// fallback: EXT_blend_minmax
			blend_substract,		// fallback: EXT_blend_subtract
			// GL 2.0 caps:
							// none yet.
			// GL 1.3 caps:
			multitexture,			// fallback: ARB_multitexture
			multisample,			// fallback: ARB_multisample
			texture_compression,		// fallback: ARB_texture_compression
			texture_cube_map,		// fallback: ARB_texture_cube_map
			texture_env_add,		// fallback: ARB_texture_env_add
			texture_env_combine,		// fallback: ARB_texture_env_combine
			texture_env_dot3,		// fallback: ARB_texture_env_dot3
			texture_border_clamp,		// fallback: ARB_texture_border_clamp
			transpose_matrix,		// fallback: ARB_transpose_matrix

			// GL 1.2 caps:
			texture3D,			// fallback: EXT_texture3D
			bgra,				// fallback: EXT_bgra
			packed_pixels,			// fallback: EXT_packed_pixels
			rescale_normal,			// fallback: EXT_rescale_normal
			separate_specular_color,	// fallback: EXT_separate_specular_color
			texture_edge_clamp,		// fallback: EXT_texture_edge_clamp or SGIS_texture_edge_clamp
			texture_lod,			// fallback: EXT_texture_lod or SGIS_texture_lod
			draw_range_elements,		// fallback: EXT_draw_range_elements
			
			// current (ARB) caps:
			point_parameters,		// fallback: EXT_point_parameters
			vertex_blend,			// 
			matrix_palette,			// 
			texture_env_crossbar,		// -if GL1.4 gets released, this wouldn't be supported anymore-
			texture_mirrored_repeat,	// fallback: IBM_texture_mirrored_repeat
			depth_texture,			// fallback: SGIX_depth_texture (unsupported)
			shadow,				// fallback: SGIX_shadow  (unsupported)
			shadow_ambient,			// fallback: SGIX_ambient (unsupported)

			// unusual (EXT) caps:
			abgr,				// 
			clip_volume_hint,		// 
			compiled_vertex_array,		// 
			fog_coord,			// 
			multi_draw_arrays,		// 
			secondary_color,		// 
			stencil_wrap,			// 
			texture_compression_s3tc,	// fallback: S3_s3tc (unsupported)
			texture_filter_anisotropic,	// 
			texture_lod_bias,		// 
			vertex_weighting,		// 
			vertex_shader,			// 
		
			// Vendor specific caps:
			// -NVidia-
			nv_blend_square,		// 
			nv_copy_depth_to_color,		// 
			nv_depth_clamp,			// 
			nv_evaluators,			// 
			nv_fence,			// 
			nv_fog_distance,		// 
			nv_light_max_exponent,		// 
			nv_multisample_filter_hint,	// -Quincunx filtering-
			nv_occlusion_query,		// 
			nv_packed_depth_stencil,	// 
			nv_point_sprite,		// 
			nv_register_combiners,		// 
			nv_register_combiners2,		// 
			nv_secondary_color_alpha,	// 
			nv_texgen_emboss,		// 
			nv_texgen_reflection,		// 
			nv_texture_compression_vtc,	// 
			nv_texture_env_combine4,	// 
			nv_texture_rectangle,		// 
			nv_texture_shader,		// 
			nv_texture_shader2,		// 
			nv_texture_shader3,		// 
			nv_vertex_array_range,		// 
			nv_vertex_array_range2,		// 
			nv_vertex_program,		// 
			nv_vertex_program1_1,		// 
			// -ATI-
			ati_envmap_bumpmap,		// 
			ati_fragment_shader,		// 
			ati_pn_triangles,		// -ATI TrueForm-
			ati_vertex_array_object,	// 
			ati_vertex_streams,		// 
			// -HP-
			hp_occlusion_test,		// -prefer nv_occlusion_query for parallelism-
			// -SGI-
			sgis_generate_mipmap,		// 
			// sgis_texture_lod,		// superseded by texture_lod
			sgis_fog_function,		// 
			sgi_vertex_preclip,		// same as sgix_vertex_preclip -HINT for fast clipping-
			// -WIN-
			win_specular_fog;		//
} GLcaps;

// Initializer:
extern const char* GLErrorString;
extern GLboolean GLInitialize(const char*);
extern void GLCheckCapabilities(GLcaps* caps);
extern void GLShutdown(void);

// Common WGL/GLX extensions
#define GLFunc(_name_, _ret_, _args_) \
typedef _ret_ (__glapi* GL##_name_##_fptr) _args_; \
extern GL##_name_##_fptr GL##_name_;
GLFunc(GetProcAddress, void*, (const GLubyte*))
#include "GL.arch"
#undef GLFunc


#ifdef __cplusplus
}
#endif

#endif

