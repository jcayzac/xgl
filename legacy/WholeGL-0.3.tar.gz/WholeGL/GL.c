#include "GL.h"
#include <string.h>

#ifdef DEBUG
#include <stdio.h>
#define CERR(x) fprintf(stderr, "%s\n", x);
#else
#define CERR(x)
#endif

#ifdef _WIN32
HMODULE OpenGLDynamicDriver = NULL;
HMODULE GDIDll = NULL;
#define DllOpen(s) LoadLibrary(s)
#define FindProc(m,s) GetProcAddress(m,s)
#define DllClose(s) FreeLibrary(s)
#else
#include <stdio.h>
#include <dlfcn.h>
void* OpenGLDynamicDriver = NULL;
#define DllOpen(s) dlopen(s, RTLD_LAZY)
#define FindProc(m,s) dlsym(m,s)
#define DllClose(s) dlclose(s)
#endif

#define GLFunc(_name_, _ret_, _args_) \
_name_##_fptr _name_ = NULL;
#include "GL.func"
#undef GLFunc
#define GLFunc(_name_, _ret_, _args_) \
GL##_name_##_fptr GL##_name_ = NULL;
GLFunc(GetProcAddress, void*, (const GLubyte*))
#include "GL.arch"
#undef GLFunc

const char* GLErrorString = NULL;

/*
 Supported core versions: 1.1, 1.2, 1.2.1, 1.3
 Supported extensions:
 ARB_multitexture ARB_multisample ARB_texture_compression ARB_texture_cube_map
 ARB_texture_env_add ARB_texture_env_combine ARB_texture_env_dot3 ARB_texture_border_clamp
 ARB_transpose_matrix ARB_point_parameters ARB_vertex_blend ARB_matrix_palette
 ARB_texture_env_crossbar ARB_texture_mirrored_repeat ARB_depth_texture ARB_shadow
 ARB_shadow_ambient ARB_imaging
 EXT_color_table EXT_color_subtable EXT_convolution EXT_histogram EXT_blend_color
 EXT_blend_minmax EXT_blend_subtract EXT_texture3D EXT_bgra EXT_packed_pixels
 EXT_rescale_normal EXT_separate_specular_color EXT_texture_edge_clamp EXT_texture_lod
 EXT_draw_range_elements EXT_point_parameters EXT_abgr EXT_clip_volume_hint
 EXT_compiled_vertex_array EXT_fog_coord EXT_multi_draw_arrays EXT_secondary_color
 EXT_stencil_wrap EXT_texture_compression_s3tc EXT_texture_filter_anisotropic
 EXT_texture_lod_bias EXT_vertex_weighting EXT_vertex_shader
 NV_blend_square NV_copy_depth_to_color NV_depth_clamp NV_evaluators NV_fence
 NV_fog_distance NV_light_max_exponent NV_multisample_filter_hint NV_point_sprite
 NV_occlusion_query NV_packed_depth_stencil NV_register_combiners NV_register_combiners2
 NV_secondary_color_alpha NV_texgen_emboss NV_texgen_reflection NV_texture_compression_vtc
 NV_texture_env_combine4 NV_texture_rectangle NV_texture_shader NV_texture_shader2
 NV_texture_shader3 NV_vertex_array_range NV_vertex_array_range2 NV_vertex_program
 NV_vertex_program1_1
 ATI_envmap_bumpmap ATI_fragment_shader ATI_pn_triangles ATI_vertex_array_object
 ATI_vertex_streams
 SGI_color_matrix SGIS_texture_lod SGIS_generate_mipmap SGIS_fog_function SGI_vertex_preclip
 HP_convolution_border_modes HP_occlusion_test
 IBM_texture_mirrored_repeat
 WIN_specular_fog
*/

#define ALIAS(s, x) \
if (s==NULL) s = x;

const GLubyte* extString = NULL;

void  __GL_CheckVersion(GLcaps* caps) { 
	// Core version
	const GLubyte* versionString = glGetString(GL_VERSION);
	CERR(versionString);
	int version=0;
	if (memcmp(versionString, "2.0", 3)==0) 
		version = 200;
	else if (memcmp(versionString, "1.3", 3)==0)
		version = 130;
	else if (memcmp(versionString, "1.2.1", 5)==0)
		version = 121;
	else if (memcmp(versionString, "1.2", 3)==0)
		version = 120;
	else if (memcmp(versionString, "1.1", 3)==0)
		version = 110;
	caps->gl_20 = caps->gl_13 = caps->gl_121 = caps->gl_12 = caps->gl_11 = GL_FALSE;
	switch(version) {
		case 200:
			caps->gl_20 = GL_TRUE;
			CERR("2.0");
		case 130:
			caps->gl_13 = GL_TRUE;
			CERR("1.3");
			// new core functions
			caps->multitexture		= GL_TRUE;
			caps->multisample		= GL_TRUE;
			caps->texture_compression	= GL_TRUE;
			caps->texture_cube_map		= GL_TRUE;
			caps->texture_env_add		= GL_TRUE;
			caps->texture_env_combine	= GL_TRUE;
			caps->texture_env_dot3		= GL_TRUE;
			caps->texture_border_clamp	= GL_TRUE;
			caps->transpose_matrix		= GL_TRUE;
		case 121:
			caps->gl_121 = GL_TRUE;
			CERR("1.2.1");
			//
		case 120:
			caps->gl_12 = GL_TRUE;
			CERR("1.2");
			//
			caps->texture3D			= GL_TRUE;
			caps->bgra			= GL_TRUE;
			caps->packed_pixels		= GL_TRUE;
			caps->rescale_normal		= GL_TRUE;
			caps->separate_specular_color	= GL_TRUE;
			caps->texture_edge_clamp	= GL_TRUE;
			caps->texture_lod		= GL_TRUE;
			caps->draw_range_elements	= GL_TRUE;
		case 110:
			caps->gl_11 = GL_TRUE;
			CERR("1.1");
		default:
			break;
	}
}

GLboolean __GL_MatchCap(const char* p, const char* ext, int cnt, GLboolean* b) {
	if(memcmp(p, ext, cnt)==0) {
		CERR(ext);
		*b = GL_TRUE;
		return GL_TRUE;
	}
	return GL_FALSE;
}

void  __GL_CheckCaps(GLcaps* caps) {
	char* c = (char*) caps;
	int i;
	for (i=0; i<sizeof(GLcaps); i++) c[i]=0;
	// Extensions
		extString	= glGetString(GL_EXTENSIONS);
	const GLubyte* pext	= extString;
	// for composited extensions:
	GLboolean i_color_table			= GL_FALSE;
	GLboolean i_color_subtable		= GL_FALSE;
	GLboolean i_convolution			= GL_FALSE;
	GLboolean i_convolution_border_modes	= GL_FALSE;
	while(1) {
		const GLubyte* pext2 = pext;
		int cnt = 0;
		while(*pext2 && *pext2!=' ' && *pext2!='\r' && *pext2!='\n') {
			*pext2++;
			cnt++;
		}
		// Imaging subset
		if (__GL_MatchCap(pext,"GL_ARB_imaging",cnt,&(caps->imaging))) {
			caps->color_table 	= GL_TRUE;
			caps->convolution 	= GL_TRUE;
			caps->color_matrix	= GL_TRUE;
			caps->histogram		= GL_TRUE;
			caps->blend_color	= GL_TRUE;
			caps->blend_minmax	= GL_TRUE;
			caps->blend_substract	= GL_TRUE;
		}
		// Imaging fallbacks
		else if (__GL_MatchCap(pext,"GL_EXT_color_table",cnt,&i_color_table)); // aliased below
		else if (__GL_MatchCap(pext,"GL_SGI_color_table",cnt,&i_color_table)); // aliased below
		else if (__GL_MatchCap(pext,"GL_EXT_color_subtable",cnt,&i_color_subtable)) {
			ALIAS(glColorSubTable, glColorSubTableEXT)
			ALIAS(glCopyColorSubTable, glCopyColorSubTableEXT)
		}
		else if (__GL_MatchCap(pext,"GL_EXT_convolution",cnt,&i_convolution)) {
			ALIAS(glConvolutionFilter1D, glConvolutionFilter1DEXT)
			ALIAS(glConvolutionFilter2D, glConvolutionFilter2DEXT)
			ALIAS(glConvolutionParameterf, glConvolutionParameterfEXT)
			ALIAS(glConvolutionParameterfv, glConvolutionParameterfvEXT)
			ALIAS(glConvolutionParameteri, glConvolutionParameteriEXT)
			ALIAS(glConvolutionParameteriv, glConvolutionParameteriv)
			ALIAS(glCopyConvolutionFilter1D, glCopyConvolutionFilter1DEXT)
			ALIAS(glCopyConvolutionFilter2D, glCopyConvolutionFilter2DEXT)
			ALIAS(glGetConvolutionFilter, glGetConvolutionFilterEXT)
			ALIAS(glGetConvolutionParameterfv, glGetConvolutionParameterfvEXT)
			ALIAS(glGetConvolutionParameteriv, glGetConvolutionParameterivEXT)
			ALIAS(glGetSeparableFilter, glGetSeparableFilterEXT)
			ALIAS(glSeparableFilter2D, glSeparableFilter2DEXT)
		}
		else if (__GL_MatchCap(pext,"GL_HP_convolution_border_modes",cnt,&i_convolution_border_modes));
		else if (__GL_MatchCap(pext,"GL_EXT_histogram",cnt,&(caps->histogram))) {
			ALIAS(glGetHistogram, glGetHistogramEXT)
			ALIAS(glGetHistogramParameterfv, glGetHistogramParameterfvEXT)
			ALIAS(glGetHistogramParameteriv, glGetHistogramParameterivEXT)
			ALIAS(glHistogram, glHistogramEXT)
			ALIAS(glResetHistogram, glResetHistogramEXT)
			ALIAS(glGetMinmax, glGetMinmaxEXT)
			ALIAS(glGetMinmaxParameterfv, glGetMinmaxParameterfvEXT)
			ALIAS(glGetMinmaxParameteriv, glGetMinmaxParameterivEXT)
			ALIAS(glMinmax, glMinmaxEXT)
			ALIAS(glResetMinmax, glResetMinmaxEXT)
		}
		else if (__GL_MatchCap(pext,"GL_SGI_color_matrix",cnt,&(caps->color_matrix)));
		else if (__GL_MatchCap(pext,"GL_EXT_blend_color",cnt,&(caps->blend_color))) {
			ALIAS(glBlendColor, glBlendColorEXT)
		}
		else if (__GL_MatchCap(pext,"GL_EXT_blend_minmax",cnt,&(caps->blend_minmax))) {
			ALIAS(glBlendEquation, glBlendEquationEXT);
		}
		else if (__GL_MatchCap(pext,"GL_EXT_blend_subtract",cnt,&(caps->blend_substract)));
		// 1.3 fallbacks
		else if (__GL_MatchCap(pext,"GL_ARB_multitexture",cnt,&(caps->multitexture))) {
			ALIAS(glActiveTexture, glActiveTextureARB)
			ALIAS(glClientActiveTexture, glClientActiveTextureARB)
			ALIAS(glMultiTexCoord1d, glMultiTexCoord1dARB)
			ALIAS(glMultiTexCoord1dv, glMultiTexCoord1dvARB)
			ALIAS(glMultiTexCoord1f, glMultiTexCoord1fARB)
			ALIAS(glMultiTexCoord1fv, glMultiTexCoord1fvARB)
			ALIAS(glMultiTexCoord1i, glMultiTexCoord1iARB)
			ALIAS(glMultiTexCoord1iv, glMultiTexCoord1ivARB)
			ALIAS(glMultiTexCoord1s, glMultiTexCoord1sARB)
			ALIAS(glMultiTexCoord1sv, glMultiTexCoord1svARB)
			ALIAS(glMultiTexCoord2d, glMultiTexCoord2dARB)
			ALIAS(glMultiTexCoord2dv, glMultiTexCoord2dvARB)
			ALIAS(glMultiTexCoord2f, glMultiTexCoord2fARB)
			ALIAS(glMultiTexCoord2fv, glMultiTexCoord2fvARB)
			ALIAS(glMultiTexCoord2i, glMultiTexCoord2iARB)
			ALIAS(glMultiTexCoord2iv, glMultiTexCoord2ivARB)
			ALIAS(glMultiTexCoord2s, glMultiTexCoord2sARB)
			ALIAS(glMultiTexCoord2sv, glMultiTexCoord2svARB)
			ALIAS(glMultiTexCoord3d, glMultiTexCoord3dARB)
			ALIAS(glMultiTexCoord3dv, glMultiTexCoord3dvARB)
			ALIAS(glMultiTexCoord3f, glMultiTexCoord3fARB)
			ALIAS(glMultiTexCoord3fv, glMultiTexCoord3fvARB)
			ALIAS(glMultiTexCoord3i, glMultiTexCoord3iARB)
			ALIAS(glMultiTexCoord3iv, glMultiTexCoord3ivARB)
			ALIAS(glMultiTexCoord3s, glMultiTexCoord3sARB)
			ALIAS(glMultiTexCoord3sv, glMultiTexCoord3svARB)
			ALIAS(glMultiTexCoord4d, glMultiTexCoord4dARB)
			ALIAS(glMultiTexCoord4dv, glMultiTexCoord4dvARB)
			ALIAS(glMultiTexCoord4f, glMultiTexCoord4fARB)
			ALIAS(glMultiTexCoord4fv, glMultiTexCoord4fvARB)
			ALIAS(glMultiTexCoord4i, glMultiTexCoord4iARB)
			ALIAS(glMultiTexCoord4iv, glMultiTexCoord4ivARB)
			ALIAS(glMultiTexCoord4s, glMultiTexCoord4sARB)
			ALIAS(glMultiTexCoord4sv, glMultiTexCoord4svARB)
		}
		else if (__GL_MatchCap(pext,"GL_ARB_multisample",cnt,&(caps->multisample))) {
			ALIAS(glSampleCoverage, glSampleCoverageARB);
			ALIAS(glSamplePass, glSamplePassARB)
		}
		else if (__GL_MatchCap(pext,"GL_ARB_texture_compression",cnt,&(caps->texture_compression))) {
			ALIAS(glCompressedTexImage3D, glCompressedTexImage3DARB)
			ALIAS(glCompressedTexImage2D, glCompressedTexImage2DARB)
			ALIAS(glCompressedTexImage1D, glCompressedTexImage1DARB)
			ALIAS(glCompressedTexSubImage3D, glCompressedTexSubImage3DARB)
			ALIAS(glCompressedTexSubImage2D, glCompressedTexSubImage2DARB)
			ALIAS(glCompressedTexSubImage1D, glCompressedTexSubImage1DARB)
			ALIAS(glGetCompressedTexImage, glGetCompressedTexImageARB)
		}
		else if (__GL_MatchCap(pext,"GL_ARB_texture_cube_map",cnt,&(caps->texture_cube_map)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_env_add",cnt,&(caps->texture_env_add)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_env_combine",cnt,&(caps->texture_env_combine)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_env_dot3",cnt,&(caps->texture_env_dot3)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_border_clamp",cnt,&(caps->texture_border_clamp)));
		else if (__GL_MatchCap(pext,"GL_ARB_transpose_matrix",cnt,&(caps->transpose_matrix))) {
			ALIAS(glLoadTransposeMatrixf, glLoadTransposeMatrixfARB)
			ALIAS(glLoadTransposeMatrixd, glLoadTransposeMatrixdARB)
			ALIAS(glMultTransposeMatrixf, glMultTransposeMatrixfARB)
			ALIAS(glMultTransposeMatrixd, glMultTransposeMatrixdARB)
		}
		// 1.2 fallbacks
		else if (__GL_MatchCap(pext,"GL_EXT_texture3D",cnt,&(caps->texture3D))) {
			ALIAS(glTexImage3D, glTexImage3DEXT);
			ALIAS(glTexSubImage3D, glTexSubImage3DEXT);
		}
		else if (__GL_MatchCap(pext,"GL_EXT_bgra",cnt,&(caps->bgra)));
		else if (__GL_MatchCap(pext,"GL_EXT_packed_pixels",cnt,&(caps->bgra)));
		else if (__GL_MatchCap(pext,"GL_EXT_rescale_normal",cnt,&(caps->rescale_normal)));
		else if (__GL_MatchCap(pext,"GL_EXT_separate_specular_color",cnt,&(caps->separate_specular_color)));
		else if (__GL_MatchCap(pext,"GL_EXT_texture_edge_clamp",cnt,&(caps->texture_edge_clamp)));
		else if (__GL_MatchCap(pext,"GL_SGIS_texture_edge_clamp",cnt,&(caps->texture_edge_clamp)));
		else if (__GL_MatchCap(pext,"GL_EXT_texture_lod",cnt,&(caps->texture_lod)));
		else if (__GL_MatchCap(pext,"GL_SGIS_texture_lod",cnt,&(caps->texture_lod)));
		else if (__GL_MatchCap(pext,"GL_EXT_draw_range_elements",cnt,&(caps->draw_range_elements))) {
			ALIAS(glDrawRangeElements, glDrawRangeElementsEXT);
		}
		// ARB extensions & promoted EXT
		else if (__GL_MatchCap(pext,"GL_EXT_point_parameters",cnt,&(caps->point_parameters))); // aliased below
		else if (__GL_MatchCap(pext,"GL_ARB_point_parameters",cnt,&(caps->point_parameters))); // aliased below
		else if (__GL_MatchCap(pext,"GL_ARB_vertex_blend",cnt,&(caps->vertex_blend))) {
			ALIAS(glWeightbv, glWeightbvARB)
			ALIAS(glWeightdv, glWeightdvARB)
			ALIAS(glWeightfv, glWeightfvARB)
			ALIAS(glWeightiv, glWeightivARB)
			ALIAS(glWeightPointer, glWeightPointerARB)
			ALIAS(glWeightsv, glWeightsvARB)
			ALIAS(glWeightubv, glWeightubvARB)
			ALIAS(glWeightuiv, glWeightuivARB)
			ALIAS(glWeightusv, glWeightusvARB)
			ALIAS(glVertexBlend, glVertexBlendARB)
		}
		else if (__GL_MatchCap(pext,"GL_ARB_matrix_palette",cnt,&(caps->matrix_palette)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_env_crossbar",cnt,&(caps->texture_env_crossbar)));
		else if (__GL_MatchCap(pext,"GL_ARB_texture_mirrored_repeat",cnt,&(caps->texture_mirrored_repeat)));
		else if (__GL_MatchCap(pext,"GL_IBM_texture_mirrored_repeat",cnt,&(caps->texture_mirrored_repeat)));
		else if (__GL_MatchCap(pext,"GL_ARB_depth_texture",cnt,&(caps->depth_texture)));
		else if (__GL_MatchCap(pext,"GL_ARB_shadow",cnt,&(caps->shadow)));
		else if (__GL_MatchCap(pext,"GL_ARB_shadow_ambient",cnt,&(caps->shadow_ambient)));
		// EXT extensions
		else if (__GL_MatchCap(pext,"GL_EXT_abgr",cnt,&(caps->abgr)));
		else if (__GL_MatchCap(pext,"GL_EXT_clip_volume_hint",cnt,&(caps->clip_volume_hint)));
		else if (__GL_MatchCap(pext,"GL_EXT_compiled_vertex_array",cnt,&(caps->compiled_vertex_array)));
		else if (__GL_MatchCap(pext,"GL_EXT_fog_coord",cnt,&(caps->fog_coord)));
		else if (__GL_MatchCap(pext,"GL_EXT_multi_draw_arrays",cnt,&(caps->multi_draw_arrays)));
		else if (__GL_MatchCap(pext,"GL_EXT_secondary_color",cnt,&(caps->secondary_color)));
		else if (__GL_MatchCap(pext,"GL_EXT_stencil_wrap",cnt,&(caps->stencil_wrap)));
		else if (__GL_MatchCap(pext,"GL_EXT_texture_compression_s3tc",cnt,&(caps->texture_compression_s3tc)));
		else if (__GL_MatchCap(pext,"GL_EXT_texture_filter_anisotropic",cnt,&(caps->texture_filter_anisotropic)));
		else if (__GL_MatchCap(pext,"GL_EXT_texture_lod_bias",cnt,&(caps->texture_lod_bias)));
		else if (__GL_MatchCap(pext,"GL_EXT_vertex_weighting",cnt,&(caps->vertex_weighting)));
		else if (__GL_MatchCap(pext,"GL_EXT_vertex_shader",cnt,&(caps->vertex_shader)));
		// NVidia
		else if (__GL_MatchCap(pext,"GL_NV_blend_square",cnt,&(caps->nv_blend_square)));
		else if (__GL_MatchCap(pext,"GL_NV_copy_depth_to_color",cnt,&(caps->nv_copy_depth_to_color)));
		else if (__GL_MatchCap(pext,"GL_NV_depth_clamp",cnt,&(caps->nv_depth_clamp)));
		else if (__GL_MatchCap(pext,"GL_NV_evaluators",cnt,&(caps->nv_evaluators)));
		else if (__GL_MatchCap(pext,"GL_NV_fence",cnt,&(caps->nv_fence)));
		else if (__GL_MatchCap(pext,"GL_NV_fog_distance",cnt,&(caps->nv_fog_distance)));
		else if (__GL_MatchCap(pext,"GL_NV_light_max_exponent",cnt,&(caps->nv_light_max_exponent)));
		else if (__GL_MatchCap(pext,"GL_NV_multisample_filter_hint",cnt,&(caps->nv_multisample_filter_hint)));
		else if (__GL_MatchCap(pext,"GL_NV_occlusion_query",cnt,&(caps->nv_occlusion_query)));
		else if (__GL_MatchCap(pext,"GL_NV_packed_depth_stencil",cnt,&(caps->nv_packed_depth_stencil)));
		else if (__GL_MatchCap(pext,"GL_NV_point_sprite",cnt,&(caps->nv_point_sprite)));
		else if (__GL_MatchCap(pext,"GL_NV_register_combiners",cnt,&(caps->nv_register_combiners)));
		else if (__GL_MatchCap(pext,"GL_NV_register_combiners2",cnt,&(caps->nv_register_combiners2)));
		else if (__GL_MatchCap(pext,"GL_NV_secondary_color_alpha",cnt,&(caps->nv_secondary_color_alpha)));
		else if (__GL_MatchCap(pext,"GL_NV_texgen_emboss",cnt,&(caps->nv_texgen_emboss)));
		else if (__GL_MatchCap(pext,"GL_NV_texgen_reflection",cnt,&(caps->nv_texgen_reflection)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_compression_vtc",cnt,&(caps->nv_texture_compression_vtc)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_env_combine4",cnt,&(caps->nv_texture_env_combine4)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_rectangle",cnt,&(caps->nv_texture_rectangle)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_shader",cnt,&(caps->nv_texture_shader)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_shader2",cnt,&(caps->nv_texture_shader2)));
		else if (__GL_MatchCap(pext,"GL_NV_texture_shader3",cnt,&(caps->nv_texture_shader3)));
		else if (__GL_MatchCap(pext,"GL_NV_vertex_array_range",cnt,&(caps->nv_vertex_array_range)));
		else if (__GL_MatchCap(pext,"GL_NV_vertex_array_range2",cnt,&(caps->nv_vertex_array_range2)));
		else if (__GL_MatchCap(pext,"GL_NV_vertex_program",cnt,&(caps->nv_vertex_program)));
		else if (__GL_MatchCap(pext,"GL_NV_vertex_program1_1",cnt,&(caps->nv_vertex_program1_1)));
		// ATI
		else if (__GL_MatchCap(pext,"GL_ATI_envmap_bumpmap",cnt,&(caps->ati_envmap_bumpmap)));
		else if (__GL_MatchCap(pext,"GL_ATI_fragment_shader",cnt,&(caps->ati_fragment_shader)));
		else if (__GL_MatchCap(pext,"GL_ATI_pn_triangles",cnt,&(caps->ati_pn_triangles)));
		else if (__GL_MatchCap(pext,"GL_ATI_vertex_array_object",cnt,&(caps->ati_vertex_array_object)));
		else if (__GL_MatchCap(pext,"GL_ATI_vertex_streams",cnt,&(caps->ati_vertex_streams)));
		// HP
		else if (__GL_MatchCap(pext,"GL_HP_occlusion_test",cnt,&(caps->hp_occlusion_test)));
		// SGI
		else if (__GL_MatchCap(pext,"GL_SGIS_generate_mipmap",cnt,&(caps->sgis_generate_mipmap)));
		else if (__GL_MatchCap(pext,"GL_SGIS_fog_function",cnt,&(caps->sgis_fog_function)));
		else if (__GL_MatchCap(pext,"GL_SGI_vertex_preclip",cnt,&(caps->sgi_vertex_preclip)));
		// WIN
		else if (__GL_MatchCap(pext,"GL_WIN_specular_fog",cnt,&(caps->win_specular_fog)));

		pext += cnt+1;
		if (pext-extString>=strlen(extString)) break;
	}
	// some composite functionalities:
	if ((i_color_table==GL_TRUE) && (i_color_subtable==GL_TRUE))		caps->color_table = GL_TRUE;
	if ((i_convolution==GL_TRUE) && (i_convolution_border_modes==GL_TRUE))	caps->convolution = GL_TRUE;
	//
	if (caps->color_table==GL_TRUE) {
		// promote SGI_color_table to EXT_color_table
		ALIAS(glColorTableEXT, glColorTableSGI)
		ALIAS(glColorTableParameterfvEXT, glColorTableParameterfvSGI)
		ALIAS(glColorTableParameterivEXT, glColorTableParameterivSGI)
		ALIAS(glCopyColorTableEXT, glCopyColorTableSGI)
		ALIAS(glGetColorTableEXT, glGetColorTableSGI)
		ALIAS(glGetColorTableParameterfvEXT, glGetColorTableParameterfvSGI)
		ALIAS(glGetColorTableParameterivEXT, glGetColorTableParameterivSGI)
		// promote EXT_color_table to core feature
		ALIAS(glColorTable, glColorTableEXT)
		ALIAS(glColorTableParameterfv, glColorTableParameterfvEXT)
		ALIAS(glColorTableParameteriv, glColorTableParameterivEXT)
		ALIAS(glCopyColorTable, glCopyColorTableEXT)
		ALIAS(glGetColorTable, glGetColorTableEXT)
		ALIAS(glGetColorTableParameterfv, glGetColorTableParameterfvEXT)
		ALIAS(glGetColorTableParameteriv, glGetColorTableParameterivEXT)
	}
	if (caps->point_parameters==GL_TRUE) {
		// promote EXT_point_parameters to ARB_point_parameters
		ALIAS(glPointParameterfARB, glPointParameterfEXT)
		ALIAS(glPointParameterfvARB, glPointParameterfvEXT)
		// promote ARB_point_parameters to core feature
		ALIAS(glPointParameterf, glPointParameterfARB)
		ALIAS(glPointParameterfv, glPointParameterfvARB)
	}
}

// Find a driver export'ed symbol (`__stdcall')
void* __GL_FindProc(char* name) {
	// The easy way
	void* res=FindProc(OpenGLDynamicDriver,name);
#ifdef _WIN32
	if (res==0L) {
		// Maybe in GDI32.dll ?
		res = FindProc(GDIDll,name);
		if (res==0L) {
			// Last chance: Try to get the GDI native call (e.g. SwapBuffers instead of wglSwapBuffers)
			if (strncmp(name, "wgl", 3)==0) res = FindProc(GDIDll,(char*)(name+3));
		}
	}
#endif
	return res;
}

// CLose shared objects
void GLShutdown(void) {
	if (OpenGLDynamicDriver) DllClose(OpenGLDynamicDriver);
#ifdef _WIN32
	if (GDIDll) DllClose(GDIDll);
#endif
}

// Initializer
GLboolean GLInitialize(const char* driverName) {
	char dummy[256];
	// Try to open the specified driver
	OpenGLDynamicDriver = DllOpen(driverName);
	if (OpenGLDynamicDriver==NULL) {
#ifdef _WIN32
		CERR("Cannot open specified OpenGL driver. Falling back to opengl32.dll");
		// Failed. Fallback to software OpenGL32.dll
		OpenGLDynamicDriver = DllOpen("opengl32.dll");
		if (OpenGLDynamicDriver==NULL) {
#endif
			// Failed. Exit.
			GLErrorString = "Could not open OpenGL driver.";
			CERR(GLErrorString);
			return GL_FALSE;
#ifdef _WIN32
		}
	}
	// Driver Ok. Now try to open GDI32.dll (needed 
	GDIDll = DllOpen("gdi32.dll");
	if (GDIDll==NULL) {
		GLErrorString = "Could not open GDI32.DLL.";
		CERR(GLErrorString);
		if (OpenGLDynamicDriver) DllClose(OpenGLDynamicDriver);
		return GL_FALSE;
	}
	// prefix for WGL extensions
	strcpy(dummy, "wgl");
	GLGetProcAddress = (GLGetProcAddress_fptr) __GL_FindProc("wglGetProcAddress");
#else
	}
	// prefix for glX extensions
	strcpy(dummy, "glX");
	GLGetProcAddress = (GLGetProcAddress_fptr) __GL_FindProc("glXGetProcAddressARB");
#endif
	if ((void*)GLGetProcAddress==NULL) {
		GLErrorString = "Your OpenGL driver seems to be broken. Please contact your vendor.";
		CERR(GLErrorString);
		GLShutdown();
		return GL_FALSE;
	}
	GLErrorString = NULL;

	// load WGL/GLX common extensions
#define GLFunc(_name_, _ret_, _args_) \
strcpy((char*)(dummy+3), #_name_); \
GL##_name_ = (GL##_name_##_fptr) GLGetProcAddress(dummy); \
if (GL##_name_==NULL) GL##_name_ = __GL_FindProc(dummy);
#include "GL.arch"
#undef GLFunc
	
	// load GL core functions & extensions
#define GLFunc(_name_, _ret_, _args_) \
_name_ = (_name_##_fptr) GLGetProcAddress(#_name_); \
if (_name_==NULL) _name_ = (_name_##_fptr) __GL_FindProc(#_name_);
#include "GL.func"
#undef GLFunc
	return GL_TRUE;
}

void GLCheckCapabilities(GLcaps* caps) {
	__GL_CheckCaps(caps);
	__GL_CheckVersion(caps);
}

