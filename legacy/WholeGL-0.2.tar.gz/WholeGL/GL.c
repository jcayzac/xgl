#include "GL.h"
#include <string.h>

#ifdef _WIN32
HMODULE OpenGLDynamicDriver;
HMODULE GDIDll;
#define DllOpen(s) LoadLibrary(s)
#define FindProc(m,s) GetProcAddress(m,s)
#define DllClose(s) FreeLibrary(s)
#else
#include <stdio.h>
#include <dlfcn.h>
void* OpenGLDynamicDriver;
#define DllOpen(s) dlopen(s, RTLD_LAZY)
#define FindProc(m,s) dlsym(m,s)
#define DllClose(s) dlclose(s)
#endif

#define GLFunc(_name_, _ret_, _args_) \
_name_##_fptr _name_;
#include "GL.func"
#undef GLFunc
#define GLFunc(_name_, _ret_, _args_) \
GL##_name_##_fptr GL##_name_;
GLFunc(GetProcAddress, void*, (const GLubyte*))
#include "GL.arch"
#undef GLFunc

const char* GLErrorString = NULL;

// core alias of ARB_multitexture
void aliasMultitexture(void) {
	int level=2;
	if (glActiveTexture==NULL) {
		level--;
		if (glActiveTextureARB==NULL) level--;
	}
	if (level==1) {
		glActiveTexture		= glActiveTextureARB;
		glClientActiveTexture	= glClientActiveTextureARB;
		glMultiTexCoord1d	= glMultiTexCoord1dARB;
		glMultiTexCoord1dv	= glMultiTexCoord1dvARB;
		glMultiTexCoord1f	= glMultiTexCoord1fARB;
		glMultiTexCoord1fv	= glMultiTexCoord1fvARB;
		glMultiTexCoord1i	= glMultiTexCoord1iARB;
		glMultiTexCoord1iv	= glMultiTexCoord1ivARB;
		glMultiTexCoord1s	= glMultiTexCoord1sARB;
		glMultiTexCoord1sv	= glMultiTexCoord1svARB;
		glMultiTexCoord2d	= glMultiTexCoord2dARB;
		glMultiTexCoord2dv	= glMultiTexCoord2dvARB;
		glMultiTexCoord2f	= glMultiTexCoord2fARB;
		glMultiTexCoord2fv	= glMultiTexCoord2fvARB;
		glMultiTexCoord2i	= glMultiTexCoord2iARB;
		glMultiTexCoord2iv	= glMultiTexCoord2ivARB;
		glMultiTexCoord2s	= glMultiTexCoord2sARB;
		glMultiTexCoord2sv	= glMultiTexCoord2svARB;
		glMultiTexCoord3d	= glMultiTexCoord3dARB;
		glMultiTexCoord3dv	= glMultiTexCoord3dvARB;
		glMultiTexCoord3f	= glMultiTexCoord3fARB;
		glMultiTexCoord3fv	= glMultiTexCoord3fvARB;
		glMultiTexCoord3i	= glMultiTexCoord3iARB;
		glMultiTexCoord3iv	= glMultiTexCoord3ivARB;
		glMultiTexCoord3s	= glMultiTexCoord3sARB;
		glMultiTexCoord3sv	= glMultiTexCoord3svARB;
		glMultiTexCoord4d	= glMultiTexCoord4dARB;
		glMultiTexCoord4dv	= glMultiTexCoord4dvARB;
		glMultiTexCoord4f	= glMultiTexCoord4fARB;
		glMultiTexCoord4fv	= glMultiTexCoord4fvARB;
		glMultiTexCoord4i	= glMultiTexCoord4iARB;
		glMultiTexCoord4iv	= glMultiTexCoord4ivARB;
		glMultiTexCoord4s	= glMultiTexCoord4sARB;
		glMultiTexCoord4sv	= glMultiTexCoord4svARB;
	}
}

void  __GL_CheckCaps(GLcaps* caps) {

}

// Here we alias extensions to core capabilities
void  __GL_AliasProc(void) {
	// ARB_multitexture -> CoreGL
	aliasMultitexture();
	
}

// Find a driver export'ed symbol (`__stdcall')
void* __GL_FindProc(char* name) {
	// The easy way
	void* res=FindProc(OpenGLDynamicDriver,name);
#ifdef _WIN32
	if (res==0L) {
		// Maybe in GDI32.dll ?
		res = FindProc(GDIDll,name);
		if (res==0L) {
			// Last change: Try to get the GDI native call (e.g. SwapBuffers instead of wglSwapBuffers)
			if (strncmp(name, "wgl", 3)==0) res = FindProc(GDIDll,(char*)(name+3));
		}
	}
#endif
	return res;
}

// CLose shared objects
void GLShutdown(void) {
	if (OpenGLDynamicDriver) DllClose(OpenGLDynamicDriver);
#ifdef _WIN32
	if (GDIDll) DllClose(GDIDll);
#endif
}

// Initializer
GLboolean GLInitialize(const char* driverName, GLcaps* caps) {
	char dummy[256];

	// Try to open the specified driver
	OpenGLDynamicDriver = DllOpen(driverName);
	if (OpenGLDynamicDriver==NULL) {
#ifdef _WIN32
		// Failed. Fallback to software OpenGL32.dll
		OpenGLDynamicDriver = DllOpen("opengl32.dll");
		if (OpenGLDynamicDriver==NULL) {
#endif
			// Failed. Exit.
			GLErrorString = "Could not open OpenGL driver.";
			return GL_FALSE;
#ifdef _WIN32
		}
	}
	// Driver Ok. Now try to open GDI32.dll (needed 
	GDIDll = DllOpen("gdi32.dll");
	if (GDIDll==NULL) {
		GLErrorString = "Could not open GDI32.DLL.";
		if (OpenGLDynamicDriver) DllClose(OpenGLDynamicDriver);
		return GL_FALSE;
	}
	// prefix for WGL extensions
	strcpy(dummy, "wgl");
	GLGetProcAddress = (GLGetProcAddress_fptr) __GL_FindProc("wglGetProcAddress");
#else
	}
	// prefix for glX extensions
	strcpy(dummy, "glX");
	GLGetProcAddress = (GLGetProcAddress_fptr) __GL_FindProc("glXGetProcAddressARB");
#endif
	if ((void*)GLGetProcAddress==NULL) {
		GLErrorString = "Your OpenGL driver seems to be broken. Please contact your vendor.";
		GLShutdown();
		return GL_FALSE;
	}
	GLErrorString = NULL;

	// load WGL/GLX common extensions
#define GLFunc(_name_, _ret_, _args_) \
strcpy((char*)(dummy+3), #_name_); \
GL##_name_ = (GL##_name_##_fptr) GLGetProcAddress(dummy);
#include "GL.arch"
#undef GLFunc
	
	// load GL core functions & extensions
#define GLFunc(_name_, _ret_, _args_) \
_name_ = (_name_##_fptr) GLGetProcAddress(#_name_);
#include "GL.func"
#undef GLFunc

	// Do function aliasing
	__GL_AliasProc();
	
	// Fill caps
	__GL_CheckCaps(caps);
	GLErrorString = NULL;
	return GL_TRUE;
}

